from rest_framework import serializers
from .models import Student, Faculty
from .models import Course, Department
from .models import Enrollment, Attendance, Grade
from .models import Announcement
from .models import CustomUser

#This converts Course model data to JSON.
class CourseSerializer(serializers.ModelSerializer):
    faculty_name = serializers.StringRelatedField(
        source='faculty', read_only=True
        )
    students = serializers.PrimaryKeyRelatedField(
        many=True, read_only=True
        )
    
    class Meta:
        model = Course
        fields = '__all__'

#This converts Student model data to JSON.
class StudentSerializer(serializers.ModelSerializer):
    courses = serializers.PrimaryKeyRelatedField(
        many=True, queryset=Course.objects.all()
        )
    course_names = serializers.StringRelatedField(
        many=True, source='courses', read_only=True
        )

    class Meta:
        model = Student
        fields = '__all__'
#This converts Faculty model data to JSON.
class FacultySerializer(serializers.ModelSerializer):
    courses = serializers.PrimaryKeyRelatedField(
        many=True, read_only=True
    )

    class Meta:
        model = Faculty
        fields = '__all__'

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = '__all__'

class EnrollmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Enrollment
        fields = '__all__'

class AttendanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendance
        fields = '__all__'

class GradeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Grade
        fields = '__all__'

class AnnouncementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Announcement
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email', 'password', 'is_student', 'is_faculty']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = CustomUser.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            is_student=validated_data.get('is_student', False),
            is_faculty=validated_data.get('is_faculty', False),
        )
        return user

                   