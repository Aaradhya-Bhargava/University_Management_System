from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StudentViewSet, CourseViewSet 
from .views import FacultyViewSet, DepartmentViewSet
from .views import EnrollmentViewSet
from .views import AttendanceViewSet
from .views import GradeViewSet
from .views import AnnouncementViewSet

router = DefaultRouter()
router.register(r'students', StudentViewSet) # This tells Django to map the URL path /api/students to StudentViewSet, allowing REST API operations.
router.register(r'courses', CourseViewSet) # This tells Django to map the URL path /api/courses to CourseViewSet, allowing REST API operations.
router.register(r'faculties', FacultyViewSet) # This tells Django to map the URL path /api/faculties/ to the FacultyViewSet, allowing REST API operations.
router.register(r'departments', DepartmentViewSet) # This tells Django to map the URL path /api/departments/ to the DepartmentViewSet, allowing REST API operations.
router.register(r'enrollments', EnrollmentViewSet)
router.register(r'attendance', AttendanceViewSet)
router.register(r'grades', GradeViewSet)
router.register(r'announcements', AnnouncementViewSet)

urlpatterns = [
    path('api/', include(router.urls)),  # This is the url for APIs, /api/
]
