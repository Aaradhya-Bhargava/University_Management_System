from rest_framework import viewsets
from .models import Student
from .serializers import StudentSerializer
from .models import Course
from .serializers import CourseSerializer
from .models import Faculty
from .serializers import FacultySerializer
from .models import Department
from .serializers import DepartmentSerializer
from .models import Enrollment
from .serializers import EnrollmentSerializer
from .models import Attendance
from .serializers import AttendanceSerializer
from .models import Grade
from .serializers import GradeSerializer
from .models import Announcement
from .serializers import AnnouncementSerializer 

from rest_framework import filters
from .permissions import IsAdminUser, IsFacultyUser, IsStudentUser
from rest_framework.permissions import IsAuthenticated


# These creates an automatic API for Students, Course, Faculty, which including: GET, POST, PUT.
class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['student_name', 'email']

    def get_queryset(self):
        user = self.request.user
        if user.is_student:
            return Student.objects.filter(email=user.email)
        return Student.objects.all()

    def get_permissions(self):
        if self.request.method in ['POST', 'PUT', 'PATCH', 'DELETE']:
            return [IsAuthenticated(), IsAdminUser()]
        return [IsAuthenticated()]

class CourseViewSet(viewsets.ModelViewSet):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['course_name']

    def get_permissions(self):
        if self.request.method in ['POST', 'PUT', 'PATCH', 'DELETE']:
            return [IsAuthenticated(), IsFacultyUser()]
        return [IsAuthenticated()]

class FacultyViewSet(viewsets.ModelViewSet):
    queryset = Faculty.objects.all()
    serializer_class = FacultySerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['faculty_name', 'email']

class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer

class EnrollmentViewSet(viewsets.ModelViewSet):
    queryset = Enrollment.objects.all()
    serializer_class = EnrollmentSerializer

class AttendanceViewSet(viewsets.ModelViewSet):
    queryset = Attendance.objects.all()
    serializer_class = AttendanceSerializer

class GradeViewSet(viewsets.ModelViewSet):
    queryset = Grade.objects.all()
    serializer_class = GradeSerializer 

class AnnouncementViewSet(viewsets.ModelViewSet):
    queryset = Announcement.objects.all()
    serializer_class = AnnouncementSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'message']       

