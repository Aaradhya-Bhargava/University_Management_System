from django.contrib import admin
from .models import CustomUser
from django.contrib.auth.admin import UserAdmin

from .models import Student, Faculty, Course, Department, Enrollment, Attendance, Grade, Announcement

admin.site.register(Student)
admin.site.register(Faculty)
admin.site.register(Course)
admin.site.register(Department)
admin.site.register(Enrollment)
admin.site.register(Attendance)
admin.site.register(Grade)
admin.site.register(Announcement)

admin.site.register(CustomUser, UserAdmin)

