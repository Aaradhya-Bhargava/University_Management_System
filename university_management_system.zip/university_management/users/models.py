from django.contrib.auth.models import AbstractUser
from django.db import models

ROLES = (
    ('admin', 'Admin'),
    ('faculty', 'Faculty'),
    ('student', 'Student'),
)

class Department(models.Model):
    department_name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.department_name

#This defines a database table called Faculty with 3 columns : name, email, department.
class Faculty(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    department = models.ForeignKey('Department', on_delete=models.CASCADE)

    def __str__(self):
        return self.name
    
#This defines a database table called Course with 4 columns : name, code, description, credit.
class Course(models.Model):
    course_name = models.CharField(max_length=250, verbose_name='Course Name')
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField()
    credits = models.IntegerField() 
    faculty = models.ForeignKey('Faculty', on_delete=models.CASCADE, null=True, blank=True, related_name='courses')
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name="courses", null=True, blank=True)
    
    def __str__(self):
        return self.course_name
    
#This defines a database table called Students with 3 columns : name, email, DOB.
class Student(models.Model):
    student_name = models.CharField(max_length=255, verbose_name='Student Name')
    email = models.EmailField(unique=True)
    date_of_birth = models.DateField()
    courses = models.ManyToManyField(Course, related_name='students')

    def __str__(self):
        return self.student_name
#This defines a database table called Enrollment.
class Enrollment(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    date_enrolled = models.DateField(auto_now_add=True)

    class Meta:
        unique_together = ('student', 'course')

#This defines a database table called Attendance
class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(
        max_length=10,
        choices=[('Present', 'Present'), ('Absent', 'Absent')]
    )

    class Meta:
        unique_together = ('student', 'course', 'date')

    def __str__(self):
        return f"{self.student.student_name} - {self.course.course_name} on {self.date} - {self.status}"

#This defines a database table called Grade
class Grade(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    grade = models.CharField(max_length=2)  # A+, B, C, etc.

    class Meta:
        unique_together = ('student', 'course')

    def __str__(self):
        return f"{self.student.student_name} - {self.course.course_name}: {self.grade}"

#This defines a database table called Announcement.
class Announcement(models.Model):
    title = models.CharField(max_length=255)
    message = models.TextField()
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    posted_by = models.ForeignKey(Faculty, on_delete=models.CASCADE)
    date_posted = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

#This defines a database table called CustomUser.    
class CustomUser(AbstractUser):
    role = models.CharField(max_length=10, choices=ROLES)

    def __str__(self):
        return f"{self.username} ({self.role})"
    