from rest_framework import serializers
from .models import Announcement

class AnnouncementSerializer(serializers.ModelSerializer):
    posted_by_name = serializers.CharField(source='posted_by.username', read_only=True)

    class Meta:
        model = Announcement
        fields = ['id', 'title', 'message', 'posted_by_name', 'created_at', 'target_roles']
        read_only_fields = ['posted_by_name', 'created_at']
        