from django.db import models
from users.models import CustomUser

class Announcement(models.Model):
    title = models.CharField(max_length=255)
    message = models.TextField()
    posted_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    target_roles = models.CharField(max_length=100, help_text='Comma separated roles: student,faculty')

    def __str__(self):
        return self.title
    