from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework import status
from .models import Announcement
from .serializers import AnnouncementSerializer

class PostAnnouncementView(generics.CreateAPIView):
    queryset = Announcement.objects.all()
    serializer_class = AnnouncementSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        if user.role not in ['faculty', 'admin']:
            raise PermissionError("Only faculty or admin can post announcements.")
        serializer.save(posted_by=user)

class ViewAnnouncementsByRole(generics.ListAPIView):
    serializer_class = AnnouncementSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        role = self.request.user.role
        return Announcement.objects.filter(target_roles__icontains=role).order_by('-created_at')
