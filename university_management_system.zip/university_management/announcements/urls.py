from django.urls import path
from .views import PostAnnouncementView, ViewAnnouncementsByRole

urlpatterns = [
    path('post/', PostAnnouncementView.as_view(), name='post-announcement'),
    path('view/', ViewAnnouncementsByRole.as_view(), name='view-announcements'),
]
