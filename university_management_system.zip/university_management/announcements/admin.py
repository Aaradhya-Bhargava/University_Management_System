from django.contrib import admin
from .models import Announcement

@admin.register(Announcement)
class AnnouncementAdmin(admin.ModelAdmin):
    list_display = ('title', 'posted_by', 'created_at', 'target_roles')
    search_fields = ('title', 'posted_by__username')
    list_filter = ('created_at',)
    