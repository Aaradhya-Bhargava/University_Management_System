from rest_framework import generics, permissions
from .models import Course
from rest_framework import serializers
from .serializers import CourseSerializer, CourseEnrollmentSerializer
from users.models import CustomUser

class CourseListView(generics.ListAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.IsAuthenticated]

class EnrollInCourseView(generics.UpdateAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseEnrollmentSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_update(self, serializer):
        course = self.get_object()
        user = self.request.user
        if user.role == 'student':
            course.students.add(user)
        else:
            raise serializers.ValidationError("Only students can enroll.")
        return serializer.save()

class AssignFacultyView(generics.UpdateAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.IsAdminUser]
