from rest_framework import serializers
from .models import Course
from users.models import CustomUser

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email', 'role']

class CourseSerializer(serializers.ModelSerializer):
    faculty = CustomUserSerializer(read_only=True)
    students = CustomUserSerializer(many=True, read_only=True)

    class Meta:
        model = Course
        fields = '__all__'

class CourseEnrollmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Course
        fields = ['students']
        