from django.urls import path
from .views import CourseListView, EnrollInCourseView, AssignFacultyView

urlpatterns = [
    path('', CourseListView.as_view(), name='course-list'),
    path('<int:pk>/enroll/', EnrollInCourseView.as_view(), name='course-enroll'),
    path('<int:pk>/assign-faculty/', AssignFacultyView.as_view(), name='assign-faculty'),
]
