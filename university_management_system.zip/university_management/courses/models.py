from django.db import models
from users.models import CustomUser  # Ensure CustomUser has a 'role' field

class Course(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField()
    
    faculty = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        limit_choices_to={'role': 'faculty'}
    )
    
    students = models.ManyToManyField(
        CustomUser,
        related_name='enrolled_courses',
        limit_choices_to={'role': 'student'},
        blank=True
    )

    def __str__(self):
        return f"{self.code} - {self.name}"
    
