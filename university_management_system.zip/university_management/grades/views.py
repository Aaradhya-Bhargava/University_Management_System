from rest_framework.views import APIView
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import Grade
from .serializers import GradeSerializer, GradeEntrySerializer
from courses.models import Course
from users.models import CustomUser

class FacultyGradeEntryView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, course_id):
        user = request.user
        try:
            course = Course.objects.get(id=course_id, faculty=user)
        except Course.DoesNotExist:
            return Response({"detail": "You are not the faculty for this course."}, status=403)

        grades_data = request.data.get('grades', [])
        for item in grades_data:
            serializer = GradeEntrySerializer(data=item)
            if serializer.is_valid():
                student_id = serializer.validated_data['student_id']
                grade = serializer.validated_data['grade']
                student = CustomUser.objects.get(id=student_id, role='student')
                Grade.objects.update_or_create(
                    course=course,
                    student=student,
                    defaults={'grade': grade}
                )
        return Response({"detail": "Grades submitted successfully."}, status=200)

class StudentGradesView(generics.ListAPIView):
    serializer_class = GradeSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role != 'student':
            return Grade.objects.none()
        return Grade.objects.filter(student=user)
