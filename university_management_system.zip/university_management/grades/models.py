from django.db import models
from courses.models import Course
from users.models import CustomUser

class Grade(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, limit_choices_to={'role': 'student'})
    grade = models.CharField(max_length=2)

    class Meta:
        unique_together = ('course', 'student')

    def __str__(self):
        return f"{self.course.code} - {self.student.username} - {self.grade}"
    