from django.contrib import admin
from .models import Grade

@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_display = ('course', 'student', 'grade')
    list_filter = ('course', 'grade')
    search_fields = ('student__username', 'course__code')
    