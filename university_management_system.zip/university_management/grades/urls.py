from django.urls import path
from .views import FacultyGradeEntryView, StudentGradesView

urlpatterns = [
    path('submit/<int:course_id>/', FacultyGradeEntryView.as_view(), name='submit-grade'),
    path('student/', StudentGradesView.as_view(), name='student-grades'),
]
