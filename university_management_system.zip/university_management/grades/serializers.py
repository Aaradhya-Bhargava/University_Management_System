from rest_framework import serializers
from .models import Grade
from users.models import CustomUser

class GradeSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.username', read_only=True)

    class Meta:
        model = Grade
        fields = ['id', 'course', 'student', 'student_name', 'grade']

class GradeEntrySerializer(serializers.Serializer):
    student_id = serializers.IntegerField()
    grade = serializers.CharField(max_length=2)
       