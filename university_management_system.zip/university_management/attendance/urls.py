from django.urls import path
from .views import FacultyMarkAttendanceView, StudentAttendanceView

urlpatterns = [
    path('mark/<int:course_id>/', FacultyMarkAttendanceView.as_view(), name='mark-attendance'),
    path('student/', StudentAttendanceView.as_view(), name='student-attendance'),
]
