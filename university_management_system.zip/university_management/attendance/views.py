from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Attendance
from .serializers import AttendanceSerializer, AttendanceMarkSerializer
from courses.models import Course
from users.models import CustomUser
from django.utils import timezone

class FacultyMarkAttendanceView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, course_id):
        user = request.user
        try:
            course = Course.objects.get(id=course_id, faculty=user)
        except Course.DoesNotExist:
            return Response({"detail": "You are not the faculty for this course."}, status=403)

        date = request.data.get('date', timezone.now().date())
        attendance_data = request.data.get('attendance', [])

        for item in attendance_data:
            serializer = AttendanceMarkSerializer(data=item)
            if serializer.is_valid():
                student_id = serializer.validated_data['student_id']
                present = serializer.validated_data['present']
                student = CustomUser.objects.get(id=student_id, role='student')
                Attendance.objects.update_or_create(
                    course=course,
                    student=student,
                    date=date,
                    defaults={'present': present}
                )
        return Response({"detail": "Attendance marked successfully."}, status=200)

class StudentAttendanceView(generics.ListAPIView):
    serializer_class = AttendanceSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role != 'student':
            return Attendance.objects.none()
        return Attendance.objects.filter(student=user).order_by('-date')
    