from rest_framework import serializers
from .models import Attendance
from users.models import CustomUser

class AttendanceSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.username', read_only=True)
    class Meta:
        model = Attendance
        fields = ['id', 'course', 'student', 'student_name', 'date', 'present']

class AttendanceMarkSerializer(serializers.Serializer):
    student_id = serializers.IntegerField()
    present = serializers.BooleanField()
    