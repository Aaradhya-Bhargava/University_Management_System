from django.db import models
from courses.models import Course
from users.models import CustomUser

class Attendance(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, limit_choices_to={'role': 'student'})
    date = models.DateField()
    present = models.BooleanField(default=False)

    class Meta:
        unique_together = ('course', 'student', 'date')

    def __str__(self):
        return f"{self.date} - {self.course.code} - {self.student.username} - {'Present' if self.present else 'Absent'}"
